module.exports = {
    DB_CONNECT:" mongodb://127.0.0.1:27017/emplopyees",
    TOKEN_SECRET:'hjgfhkjhkfdud'
    
}
