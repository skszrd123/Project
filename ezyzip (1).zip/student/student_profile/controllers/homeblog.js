const form = require("../models/blog");
const path = require('path');
const bodyParser = require('body-parser');
var fs = require('fs');

exports.getPost = async (req, res, next) => {
  try {
  const result = await form.find({}).select('title');
  console.log(result)
    res.render('home', {
      pageTitle: 'Home | Form',
      newPost: 'New User',
      back: '',
      edit: '',
      id: '',
      value: 1,
      del: '',
      result: result,
      path: '/admin/add-product'
    });
  }catch(error){
    console.log(console.log(error));
  }
  };

  exports.getNewPost = (req, res, next) => {
    
    res.render('newpost', {
      pageTitle: 'Form | New User',
      newPost: '',
      edit: '',
      id: '',
      del: '',
      value: 1,
      back: 'back to home',
      path: '/admin/add-product'
    });
  };

  exports.getInfo = async (req, res, next) => {
    var id = req.params.id;
    
    console.log(id)
    try {
    var ObjectId = require('mongoose').Types.ObjectId;
    const result = await form.find({"_id" :ObjectId(id.trim())});
    console.log(result);
   
    
    res.render('info', {
      pageTitle: 'Form | Info',
      id:id,
      newPost: '',
      edit: 'Edit',
      del: 'Delete',
      back: 'Home',
      data: result,
      path: '/admin/add-product'
    });
  }catch(error){
    console.log(console.log(error));
  }
  };

  exports.getHomePost = async (req, res, next) => {
    try {
      if(!req.files)
    res.send("dont choose file")
    else{
    console.log(req.files)
    var imagefile=req.files.file
    var imagename=req.files.file.name
    
    imagefile.mv(path.join(__dirname, '../public/uploads')+imagename,function(err){
        if (err){
            res.send(err)
        }
    })
    }

    const blogDate = new form({
      title: req.body.title,
      categories: req.body.categories,
      content: req.body.content,
      image: imagename
    });
    const createBlog = await blogDate.save();
    console.log(createBlog)
    res.redirect('/home');
  }catch(error) {
    res.status(400).send(error);
  };
  };
  

  exports.getlogin = async (req, res, next) => {
    
  

    res.render('login',{
    });
  
  };

  exports.postlogin = async (req, res, next) => {
    Eemail=req.body.email;
    Ppassword=req.body.password;
    code=12;
    console.log(Ppassword);
    const axios = require('axios')

axios
  .post('http://localhost:3000/api/user/login', {
    email: Eemail,
    password: Ppassword
  })
  .then(response => {
    if(response.data.length>30)
    {
      res.redirect("/home");
    }
    else{
      res.send("wrong password");
    }
    console.log(`statusCode: ${response.data}`)
    console.log(response)
  })
  .catch(error => {
    console.error(error)
  })
  
    
  };
  exports.getUserlogin = async (req, res, next) => {
    
  

    res.render('userlogin',{
    });
  
  };

  exports.postUserlogin = async (req, res, next) => {
    Eemail=req.body.email;
    Ppassword=req.body.password;
    code=12;
    console.log(Ppassword);
    const axios = require('axios')

axios
  .post('http://localhost:3000/api/user/login', {
    email: Eemail,
    password: Ppassword
  })
  .then(response => {
    if(response.data.length>30)
    {
      res.redirect("/home");
    }
    else{
      res.send("wrong password");
    }
    console.log(`statusCode: ${response.data}`)
    console.log(response)
  })
  .catch(error => {
    console.error(error)
  })
  
    
  };

  exports.getsignup = async (req, res, next) => {
    res.render('signup',{
    });
  
  };

  exports.postsignup = async (req, res, next) => {
    Eemail=req.body.email;
    Ppassword=req.body.password;
    Nname=req.body.name;
    
    console.log(Ppassword);
    const axios = require('axios')

axios
  .post('http://localhost:3000/api/user/register', {
    name: Nname,
    email: Eemail,
    password: Ppassword
  })
  .then(response => {
  
   if(response.data=="email already exist") {
    res.send("email alredy exits");
    }
    else if(response.data=='"email" must be a valid email'){
      res.send('"email" must be a valid email');
      
    }else if(response.data=='"name" length must be at least 5 characters long'){
      res.send('"name" length must be at least 5 characters long');
      console.log("ggggg");
    }else{
      res.redirect("/login");
    }
    
   
    console.log(typeof response.data);
    console.log(`statusCode: ${response.data}`)
    //console.log(res)
  })
  .catch(error => {
    console.error(error)
  })
  };