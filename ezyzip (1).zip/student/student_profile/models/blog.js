const mongoose = require('mongoose')
require('../util/connection')
const blogDate = new mongoose.Schema({
    title : {
        type: String,
        required : true
    },
    categories : {
        type: String,
        required : true
    },
    content : {
        type: String,
        required : true
    },
    image : {
        type: String,
        required : true
    }
   
});

const Playlist = new mongoose.model("BlogApp",blogDate);
module.exports = Playlist;