const path = require('path');
const bodyParser = require('body-parser');
const express = require('express');
const urlencoderParser = bodyParser.urlencoded({ extended: false});
const postController = require('../controllers/homeblog.js');

const router = express.Router();


router.get('/login', postController.getlogin);
router.post('/login', postController.postlogin);
router.get('/userlogin', postController.getUserlogin);
router.post('/userlogin', postController.postUserlogin);

router.get('/home', postController.getPost);
router.post('/home',urlencoderParser, postController.getHomePost);

router.get('/new', postController.getNewPost);
router.get('/info/:id', postController.getInfo);

router.get('/signup', postController.getsignup);
router.post('/signup', postController.postsignup);



module.exports = router;