const mongoose = require("mongoose")

mongoose.connect("mongodb://localhost:27017/blog", {
     useNewUrlParser: true,
     useUnifiedTopology: true,
     useCreateIndex: true})
.then( () => console.log("connection succesful ..."))
.catch( (err) => console.log(err));

// const blogDate = new mongoose.Schema({
//     title : {
//         type: String,
//         required : true
//     },
//     categories : {
//         type: String,
//         required : true
//     },
//     content : {
//         type: String,
//         required : true
//     }
// });

// const Playlist = new mongoose.model("Blog",blogDate);

